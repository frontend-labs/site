<?php 
/**
 * Code Box
 * Page Composer Section
 *
 * @package SimpleMag
 * @since 	SimpleMag 2.0
**/
?>

<section class="wrapper home-section advertising">
	<?php the_sub_field( 'ad_banner_code' ); ?>
</section><!-- Code Box -->